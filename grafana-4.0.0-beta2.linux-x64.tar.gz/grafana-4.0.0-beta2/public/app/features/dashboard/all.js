/*! grafana - v4.0.0-beta2 - 2016-11-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./dashboard_ctrl","./alerting_srv","./dashboardLoaderSrv","./dashnav/dashnav","./submenu/submenu","./saveDashboardAsCtrl","./shareModalCtrl","./shareSnapshotCtrl","./dashboard_srv","./viewStateSrv","./timeSrv","./unsavedChangesSrv","./timepicker/timepicker","./graphiteImportCtrl","./importCtrl","./impression_store","./upload","./import/dash_import","./export/export_modal","./dash_list_ctrl","./ad_hoc_filters","./row/row_ctrl","./repeat_option/repeat_option"],function(){});