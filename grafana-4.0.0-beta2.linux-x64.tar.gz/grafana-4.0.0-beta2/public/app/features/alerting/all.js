/*! grafana - v4.0.0-beta2 - 2016-11-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./alert_list_ctrl","./notifications_list_ctrl","./notification_edit_ctrl"],function(a){return{setters:[function(a){},function(a){},function(a){}],execute:function(){}}});