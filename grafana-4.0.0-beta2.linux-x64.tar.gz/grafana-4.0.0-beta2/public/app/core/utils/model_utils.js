/*! grafana - v4.0.0-beta2 - 2016-11-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a){function b(a,b,c){for(var d in c)c.hasOwnProperty(d)&&(a[d]=void 0===b[d]?c[d]:b[d])}return a("assignModelProperties",b),{setters:[],execute:function(){}}});