/*! grafana - v4.0.0-beta2 - 2016-11-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

