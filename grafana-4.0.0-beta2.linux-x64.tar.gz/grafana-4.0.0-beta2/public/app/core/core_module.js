/*! grafana - v4.0.0-beta2 - 2016-11-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["angular"],function(a){var b;return{setters:[function(a){b=a}],execute:function(){a("default",b["default"].module("grafana.core",["ngRoute"]))}}});