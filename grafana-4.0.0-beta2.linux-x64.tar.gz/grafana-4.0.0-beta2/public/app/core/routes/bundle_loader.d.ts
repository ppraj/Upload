/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class BundleLoader {
    lazy: any;
    constructor(bundleName: any);
}
